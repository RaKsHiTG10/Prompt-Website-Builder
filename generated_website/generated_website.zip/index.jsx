
import React from 'react';
import { Button, Container, Typography } from '@mui/material';

const App = () => {
  return (
    <div style={{ padding: '2rem' }}>
      <h1>Practice Management</h1>
      <p>(AI generation failed: Command '['ollama', 'run', 'mistral']' timed out after 180 seconds)</p>
    </div>
  );
}

export default App;
