
import React from 'react';


const App = () => {
  return (
    <div style={{ padding: '2rem' }}>
      <h1>Cute</h1>
      <p>Cuteness is a type of attractiveness commonly associated with youth and appearance, as well as a scientific concept and analytical model in ethology, first introduced by Austrian ethologist Konrad Lorenz.  Lorenz proposed the concept of baby schema (Kindchenschema), a set of facial and body features that make a creature appear "cute" and activate ("release") in others the motivation to care for it.  Cuteness may be ascribed to people as well as things that are regarded as attractive or charming.</p>
    </div>
  );
}

export default App;
